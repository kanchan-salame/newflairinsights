@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <h1>This is create page..</h1>
        </div>
        <!-- /.row -->
    </div>
@endsection
